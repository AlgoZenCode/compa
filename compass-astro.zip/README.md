# Compass

A lightweight Astro online compass starter.

## Run

```bash
npm install
npm run dev
```

Open the local URL shown by Astro.

For real device compass testing, use HTTPS in production. Some browsers require a secure context and explicit motion/orientation permission.
