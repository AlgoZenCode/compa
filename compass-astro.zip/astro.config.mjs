import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://compass.example.com'
});